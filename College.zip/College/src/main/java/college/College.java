package college;
import java.util.ArrayList;
import java.util.Scanner;

public class College {
    private static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*******************************************");

        while (true) {
            System.out.println("Enter (1) to launch menu or any other key to exit:");
            String input = scanner.nextLine();

            if ("1".equals(input)) {
                displayMenu(scanner);
            } else {
               
                System.out.println("Exiting the application.");
                break;
            }
        }

        scanner.close();
    }

    private static void displayMenu(Scanner scanner) {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit application.");
        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                Student.SaveStudent(scanner, students);
                break;
            case "2":
                Student.SearchStudent(scanner, students);
                break;
            case "3":
                Student.DeleteStudent(scanner, students);

                break;
            case "4":
                Student.StudentReport(students);
                break;
            case "5":
                Student.ExitStudentApplication();
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }

        System.out.println("Enter (1) to launch menu or any other key to exit:");
        String input = scanner.nextLine();

        if ("1".equals(input)) {
            displayMenu(scanner);
        } else {
            System.out.println("Exiting the application.");
            System.exit(0);
        }
    }
}
