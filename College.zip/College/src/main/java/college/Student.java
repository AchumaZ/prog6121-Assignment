package college;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private String studentId;
    private String studentName;
    private int studentAge;
    private String studentEmail;
    private String studentCourse;

    public Student(String studentId, String studentName, int studentAge, String studentEmail, String studentCourse) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentEmail = studentEmail;
        this.studentCourse = studentCourse;
    }

    public static void SaveStudent(Scanner scanner, ArrayList<Student> students) {
        System.out.println("CAPTURE A NEW STUDENT");

        System.out.print("Enter the student ID: ");
        String studentId = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter the student age: ");

        int studentAge;
        while (true) {
            String ageInput = scanner.nextLine();

            try {
                studentAge = Integer.parseInt(ageInput);
                if (studentAge >= 16) {
                    break; 
                } else {
                    System.out.println("You have entered an incorrect student age!!!");
                    System.out.print("Please re-enter the student age >> ");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                System.out.print("Please re-enter the student age >> ");
            }
        }

        System.out.print("Enter the student email: ");
        String studentEmail = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String studentCourse = scanner.nextLine();

        Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        students.add(student);
     
        System.out.println("Student captured successfully.");
        System.out.println();
    }

    public String getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    public static void StudentReport(ArrayList<Student> students) {
        int studentNumber = 1;
        for (Student student : students) {
            System.out.println("STUDENT " + studentNumber);
            System.out.println("---------------------------");
            System.out.println("STUDENT ID: " + student.getStudentId());
            System.out.println("STUDENT NAME: " + student.getStudentName());
            System.out.println("STUDENT EMAIL: " + student.getStudentEmail());
            System.out.println("---------------------------");

            studentNumber++;
        }
    }

    public static void SearchStudent(Scanner scanner, ArrayList<Student> students) {
        System.out.print("Enter the student id to search: \n"); 
        String studentId = scanner.nextLine();
        System.out.println("----------------------------------------");
        boolean found = false;
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                System.out.println("STUDENT ID: " + student.getStudentId());
                System.out.println("NAME: " + student.getStudentName());
                System.out.println("AGE: " + student.getStudentAge());
                System.out.println("EMAIL: " + student.getStudentEmail());
                System.out.println("COURSE: " + student.getStudentCourse());
                System.out.println("----------------------------------------");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student with Student Id: " + studentId + " was not found!");
        }
    }
    

    public static void DeleteStudent(Scanner scanner, ArrayList<Student> students) {

        System.out.print("Enter the student id to delete: ");
        String studentId = scanner.nextLine();
        System.out.println("Are you sure you want to delete student " + studentId + " from the system> Yes (y) to delete.");
        String deleteConfirmation = scanner.nextLine();
        if (!deleteConfirmation.equals("y")) {
            return;
        }

        System.out.println("----------------------------------------");

        for (int i = 0; i< students.size();i++) {
            if (students.get(i).studentId.equals(studentId)) {
                students.remove(i);
                System.out.println("Student with Student Id: " + studentId + " WAS deleted!");

                System.out.println("----------------------------------------");
                break;
            } else {
                System.out.println("Student with Student Id: " + studentId + " was not found!");
            }
        }
    }

    public static void ExitStudentApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
    
    @Override
    public String toString() {
        return "STUDENT ID: " + studentId + "\n" +
               "NAME: " + studentName + "\n" +
               "AGE: " + studentAge + "\n" +
               "EMAIL: " + studentEmail + "\n" +
               "COURSE: " + studentCourse;
    }
}
