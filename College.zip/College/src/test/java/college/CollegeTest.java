package college;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class CollegeTest {

    private String captureOutput(Runnable runnable) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        try {
            runnable.run();
        } finally {
            System.setOut(originalOut);
        }

        return outputStream.toString();
    }

    private void assertNormalizedEquals(String expected, String actual) {
        String normalizedExpected = expected
                .replaceAll("\\r\\n|\\r", "\n")
                .replaceAll("\\s+", " ")
                .trim();
    
        String normalizedActual = actual
                .replaceAll("\\r\\n|\\r", "\n")
                .replaceAll("\\s+", " ")
                .trim();
    
        assertEquals(normalizedExpected, normalizedActual, "Output mismatch: ");
    }
    

    @Test
    public void TestSaveStudent() {
        ArrayList<Student> students = new ArrayList<>();
        Scanner scanner = new Scanner("12345\nJohn Doe\n18\njohn.doe@example.com\nComputer Science\n");

        Student.SaveStudent(scanner, students);

        assertEquals(1, students.size());
        Student student = students.get(0);
        assertEquals("12345", student.getStudentId());
        assertEquals("John Doe", student.getStudentName());
        assertEquals(18, student.getStudentAge());
        assertEquals("john.doe@example.com", student.getStudentEmail());
        assertEquals("Computer Science", student.getStudentCourse());
    }

    @Test
    public void TestSearchStudent() {
        ArrayList<Student> students = new ArrayList<>();
        Student student = new Student("12345", "John Doe", 18, "john.doe@example.com", "Computer Science");
        students.add(student);

        Scanner scanner = new Scanner("12345\n");

        String expectedOutput = "Enter the student id to search: \n" +
                                "----------------------------------------\n" +
                                "STUDENT ID: 12345\n" +
                                "NAME: John Doe\n" +
                                "AGE: 18\n" +
                                "EMAIL: john.doe@example.com\n" +
                                "COURSE: Computer Science\n" +
                                "----------------------------------------";
        String actualOutput = captureOutput(() -> Student.SearchStudent(scanner, students));

        assertNormalizedEquals(expectedOutput, actualOutput);
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        ArrayList<Student> students = new ArrayList<>();

        Scanner scanner = new Scanner("12345\n");

        String expectedOutput = "Enter the student id to search: ---------------------------------------- Student with Student Id: 12345 was not found!\n";
        String actualOutput = captureOutput(() -> Student.SearchStudent(scanner, students));

        assertNormalizedEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testDeleteStudent() {
        ArrayList<Student> students = new ArrayList<>();
        Student student = new Student("12345", "John Doe", 18, "john.doe@example.com", "Computer Science");
        students.add(student);
    
        Scanner scanner = new Scanner("12345\ny\n");
    
        String expectedOutput = "Enter the student id to delete: Are you sure you want to delete student 12345 from the system> Yes (y) to delete.\n" +
                                "----------------------------------------\n" +
                                "Student with Student Id: 12345 WAS deleted!\n" +
                                "----------------------------------------\n";
        String actualOutput = captureOutput(() -> Student.DeleteStudent(scanner, students));
    
        assertNormalizedEquals(expectedOutput, actualOutput);
        assertTrue(students.isEmpty());
    }
    

    @Test
    public void testDeleteStudentNotFound() {
        ArrayList<Student> students = new ArrayList<>();
        Student student = new Student("12345", "John Doe", 18, "john.doe@example.com", "Computer Science");
        students.add(student);

        Scanner scanner = new Scanner("67890\ny\n");

        String expectedOutput = "Enter the student id to delete: Are you sure you want to delete student 67890 from the system> Yes (y) to delete.\n" +
                                "----------------------------------------\n" +
                                "Student with Student Id: 67890 was not found!";
        String actualOutput = captureOutput(() -> Student.DeleteStudent(scanner, students));

        assertNormalizedEquals(expectedOutput, actualOutput);
        assertEquals(1, students.size()); 
    }


    @Test
    public void TestStudentAge_StudentAgeValid() {
        ArrayList<Student> students = new ArrayList<>();
        Scanner scanner = new Scanner("12345\nJane Doe\n17\njane.doe@example.com\nMathematics\n");

        Student.SaveStudent(scanner, students);

        assertEquals(1, students.size());
        assertEquals(17, students.get(0).getStudentAge(), "Student age should be valid.");
    }


    @Test
    public void testStudentAge_StudentAgeValidCharacter() {
        ArrayList<Student> students = new ArrayList<>();
        Scanner scanner = new Scanner("12345\nJane Doe\n18\njane.doe@example.com\nMathematics\n");

        Student.SaveStudent(scanner, students);

        assertEquals(1, students.size());
        assertEquals(18, students.get(0).getStudentAge(), "The student age should be valid.");
    }
}
