
import java.util.Scanner;

// Parent class BankAccount
class BankAccount {
    private String accountNumber;
    private double balance;

    // Constructor
    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Getters
    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }

    // Display account details
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
}

// Child class for Savings Account
class SavingsAccount extends BankAccount {
    private double interestRate;

    public SavingsAccount(String accountNumber, double initialBalance, double interestRate) {
        super(accountNumber, initialBalance);  // Call the parent class constructor
        this.interestRate = interestRate;
    }

    // Method to apply interest
    public void applyInterest() {
        double interest = getBalance() * interestRate / 100;
        deposit(interest);
        System.out.println("Applied Interest: " + interest);
    }
}

// Main class
public class BankingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Creating an array of BankAccount objects
        BankAccount[] accounts = new BankAccount[2];
        accounts[0] = new BankAccount("1001", 500);
        accounts[1] = new SavingsAccount("1002", 1000, 5);  // Savings account with 5% interest

        boolean exit = false;
        while (!exit) {
            System.out.println("\nMenu:");
            System.out.println("1. View Account Info");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Apply Interest (Savings Account only)");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    for (BankAccount account : accounts) {
                        account.displayAccountInfo();
                    }
                    break;
                case 2:
                    System.out.print("Enter account number: ");
                    String accNum = scanner.next();
                    BankAccount accountToDeposit = findAccount(accounts, accNum);
                    if (accountToDeposit != null) {
                        System.out.print("Enter amount to deposit: ");
                        double depositAmount = scanner.nextDouble();
                        accountToDeposit.deposit(depositAmount);
                    }
                    break;
                case 3:
                    System.out.print("Enter account number: ");
                    String accNumWithdraw = scanner.next();
                    BankAccount accountToWithdraw = findAccount(accounts, accNumWithdraw);
                    if (accountToWithdraw != null) {
                        System.out.print("Enter amount to withdraw: ");
                        double withdrawAmount = scanner.nextDouble();
                        accountToWithdraw.withdraw(withdrawAmount);
                    }
                    break;
                case 4:
                    for (BankAccount account : accounts) {
                        if (account instanceof SavingsAccount) {
                            ((SavingsAccount) account).applyInterest();
                        }
                    }
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }

        scanner.close();
    }

    // Method to find an account by account number
    public static BankAccount findAccount(BankAccount[] accounts, String accountNumber) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        System.out.println("Account not found.");
        return null;
    }
}