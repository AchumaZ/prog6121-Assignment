import org.junit.Test;
import static org.junit.Assert.*;

public class BankAccountTest {

    @Test
    public void testDeposit() {
        BankAccount account = new BankAccount("1001", 500);
        account.deposit(200);
        assertEquals(700, account.getBalance(), 0); // Expected balance is 700
    }

    @Test
    public void testWithdraw() {
        BankAccount account = new BankAccount("1001", 500);
        account.withdraw(200);
        assertEquals(300, account.getBalance(), 0); // Expected balance is 300
    }

    @Test
    public void testWithdrawExceedingBalance() {
        BankAccount account = new BankAccount("1001", 500);
        account.withdraw(600);  // Withdrawal should fail as it exceeds balance
        assertEquals(500, account.getBalance(), 0); // Balance remains 500
    }

    @Test
    public void testNegativeDeposit() {
        BankAccount account = new BankAccount("1001", 500);
        account.deposit(-100);  // Invalid deposit
        assertEquals(500, account.getBalance(), 0); // Balance remains 500
    }

    @Test
    public void testSavingsAccountInterest() {
        SavingsAccount savings = new SavingsAccount("1002", 1000, 5); // 5% interest
        savings.applyInterest();
        assertEquals(1050, savings.getBalance(), 0); // Expected balance after interest is applied
    }
}